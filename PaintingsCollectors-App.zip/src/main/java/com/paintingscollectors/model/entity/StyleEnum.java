package com.paintingscollectors.model.entity;

public enum StyleEnum {
    IMPRESSIONISM, ABSTRACT, EXPRESSIONISM, SURREALISM, REALISM
}
